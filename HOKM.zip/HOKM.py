import random
rulings = ["+", "-", "*", "#"]
numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
your_hand = []
comp = []
hand_score = {

}
comp_hand_score = {


}


def ROLLS():
    print(''' The order is :
          1)+
          2)-
          3)*
          4)#
          Then the numbers _''')


def make_your_hand():
    for x in range(10):
        x = random.choice(rulings)
        y = random.choice(numbers)
        z = x+y
        score_a(x, y)
        your_hand.append(z)


def score_a(x, y):
    point = 0
    if x == "+":
        point = 4
    elif x == "-":
        point = 3
    elif x == "*":
        point = 2
    else:
        point = 1
    point = point+int(y)
    hand_score.__setitem__(x+y, point)


def comp_hand():
    for x in range(10):
        x = random.choice(rulings)
        y = random.choice(numbers)
        z = x+y
        score_b(x, y)
        comp.append(z)


def score_b(x, y):
    point = 0
    if x == "+":
        point = 4
    elif x == "-":
        point = 3
    elif x == "*":
        point = 2
    else:
        point = 1
    point = point+int(y)
    comp_hand_score.__setitem__(x+y, point)


def comp_turn():
    game_p = random.choice(comp)
    print("your rival card is : ", game_p)
    rivals = comp_hand_score.get(game_p)
    return rivals


def your_turn():
    print(your_hand)
    choice = input("which one to play? ")
    print(choice)
    your_hand.remove(choice)
    print(your_hand)
    yours = hand_score.get(choice)
    return yours


def scoring():
    x = your_turn()
    print(x)


def play():
    y_f_point = 0
    r_final_point = 0
    make_your_hand()
    comp_hand()
    comp_turn()
    your_turn()
    scoring()


print('''1)To khow the rolls press the r 
      2)to play oress p
      ''')


def game():
    ready = input("choose : ")
    match ready:
        case "r":
            ROLLS()
        case"p":
            play()


game()
